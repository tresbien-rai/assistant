/**
 * AI Assistant - Main Application Logic
 * 
 * This file handles:
 * - Settings management (save/load from localStorage)
 * - API communication with Claude
 * - Message display and conversation history
 * - UI interactions (sidebar, input, etc.)
 */

// ===== Configuration =====
const CONFIG = {
    // API endpoints for different providers
    endpoints: {
        anthropic: 'https://api.anthropic.com/v1/messages'
    },
    // Default settings
    defaults: {
        provider: 'anthropic',
        model: 'claude-sonnet-4-20250514',
        assistantName: 'Assistant',
        systemPrompt: 'You are a helpful, friendly assistant. You provide clear and concise answers while being warm and personable.'
    },
    // Local storage keys
    storageKeys: {
        settings: 'ai_assistant_settings',
        conversations: 'ai_assistant_conversations'
    }
};

// ===== State Management =====
// This object holds all the current state of our app
const state = {
    settings: {
        provider: CONFIG.defaults.provider,
        model: CONFIG.defaults.model,
        apiKey: '',
        assistantName: CONFIG.defaults.assistantName,
        systemPrompt: CONFIG.defaults.systemPrompt
    },
    conversation: [], // Array of {role: 'user'|'assistant', content: string}
    isLoading: false
};

// ===== DOM Elements =====
// We grab references to all the elements we'll need to interact with
const elements = {
    // Sidebar
    sidebar: document.getElementById('sidebar'),
    openSidebar: document.getElementById('openSidebar'),
    closeSidebar: document.getElementById('closeSidebar'),
    
    // Settings inputs
    providerSelect: document.getElementById('providerSelect'),
    modelSelect: document.getElementById('modelSelect'),
    apiKeyInput: document.getElementById('apiKeyInput'),
    toggleApiKey: document.getElementById('toggleApiKey'),
    assistantName: document.getElementById('assistantName'),
    systemPrompt: document.getElementById('systemPrompt'),
    saveSettings: document.getElementById('saveSettings'),
    clearChat: document.getElementById('clearChat'),
    
    // Chat area
    messagesContainer: document.getElementById('messagesContainer'),
    messageInput: document.getElementById('messageInput'),
    sendButton: document.getElementById('sendButton'),
    
    // Header
    headerAssistantName: document.getElementById('headerAssistantName'),
    assistantAvatar: document.getElementById('assistantAvatar'),
    modelIndicator: document.getElementById('modelIndicator')
};

// ===== Initialization =====
// This runs when the page loads
function init() {
    loadSettings();
    setupEventListeners();
    updateUI();
    
    // Create overlay for mobile sidebar
    createSidebarOverlay();
    
    console.log('AI Assistant initialized!');
}

// ===== Settings Management =====

/**
 * Load settings from localStorage
 * If no settings exist, use defaults
 */
function loadSettings() {
    const saved = localStorage.getItem(CONFIG.storageKeys.settings);
    
    if (saved) {
        try {
            const parsed = JSON.parse(saved);
            // Merge saved settings with defaults (in case we add new settings later)
            state.settings = { ...CONFIG.defaults, ...parsed };
        } catch (e) {
            console.error('Failed to parse saved settings:', e);
        }
    }
    
    // Also load conversation history
    const savedConvo = localStorage.getItem(CONFIG.storageKeys.conversations);
    if (savedConvo) {
        try {
            state.conversation = JSON.parse(savedConvo);
        } catch (e) {
            console.error('Failed to parse saved conversation:', e);
        }
    }
}

/**
 * Save current settings to localStorage
 */
function saveSettings() {
    // Get values from form inputs
    state.settings.provider = elements.providerSelect.value;
    state.settings.model = elements.modelSelect.value;
    state.settings.apiKey = elements.apiKeyInput.value;
    state.settings.assistantName = elements.assistantName.value || CONFIG.defaults.assistantName;
    state.settings.systemPrompt = elements.systemPrompt.value || CONFIG.defaults.systemPrompt;
    
    // Save to localStorage
    localStorage.setItem(CONFIG.storageKeys.settings, JSON.stringify(state.settings));
    
    // Update the UI to reflect new settings
    updateUI();
    
    // Show confirmation
    showNotification('Settings saved!', 'success');
    
    // Close sidebar on mobile
    closeSidebar();
}

/**
 * Save conversation to localStorage
 */
function saveConversation() {
    localStorage.setItem(CONFIG.storageKeys.conversations, JSON.stringify(state.conversation));
}

// ===== UI Updates =====

/**
 * Update all UI elements to reflect current state
 */
function updateUI() {
    // Update form inputs
    elements.providerSelect.value = state.settings.provider;
    elements.modelSelect.value = state.settings.model;
    elements.apiKeyInput.value = state.settings.apiKey;
    elements.assistantName.value = state.settings.assistantName;
    elements.systemPrompt.value = state.settings.systemPrompt;
    
    // Update header
    elements.headerAssistantName.textContent = state.settings.assistantName;
    elements.modelIndicator.textContent = getModelDisplayName(state.settings.model);
    
    // Update send button state
    updateSendButtonState();
    
    // Render existing conversation
    renderConversation();
}

/**
 * Get a user-friendly model name for display
 */
function getModelDisplayName(modelId) {
    const modelNames = {
        'claude-sonnet-4-20250514': 'Claude Sonnet 4',
        'claude-haiku-4-20250514': 'Claude Haiku 4'
    };
    return modelNames[modelId] || modelId;
}

/**
 * Enable/disable send button based on whether we have an API key and message
 */
function updateSendButtonState() {
    const hasApiKey = state.settings.apiKey.length > 0;
    const hasMessage = elements.messageInput.value.trim().length > 0;
    const notLoading = !state.isLoading;
    
    elements.sendButton.disabled = !(hasApiKey && hasMessage && notLoading);
}

/**
 * Render all messages in the conversation
 */
function renderConversation() {
    // Clear existing messages
    elements.messagesContainer.innerHTML = '';
    
    // If no messages, show welcome
    if (state.conversation.length === 0) {
        elements.messagesContainer.innerHTML = `
            <div class="welcome-message">
                <h1>Welcome!</h1>
                <p>${state.settings.apiKey ? 'Start chatting with ' + state.settings.assistantName + '!' : 'Configure your API key in the settings (☰) to get started.'}</p>
            </div>
        `;
        return;
    }
    
    // Render each message
    state.conversation.forEach(msg => {
        appendMessage(msg.role, msg.content, false);
    });
    
    // Scroll to bottom
    scrollToBottom();
}

/**
 * Add a single message to the display
 * @param {string} role - 'user' or 'assistant'
 * @param {string} content - The message text
 * @param {boolean} save - Whether to save to conversation history
 */
function appendMessage(role, content, save = true) {
    // Remove welcome message if present
    const welcome = elements.messagesContainer.querySelector('.welcome-message');
    if (welcome) {
        welcome.remove();
    }
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = content;
    
    messageDiv.appendChild(contentDiv);
    elements.messagesContainer.appendChild(messageDiv);
    
    // Save to conversation history
    if (save) {
        state.conversation.push({ role, content });
        saveConversation();
    }
    
    scrollToBottom();
}

/**
 * Show an error message in the chat
 */
function appendErrorMessage(errorText) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message error';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = `Error: ${errorText}`;
    
    messageDiv.appendChild(contentDiv);
    elements.messagesContainer.appendChild(messageDiv);
    
    scrollToBottom();
}

/**
 * Show typing indicator while waiting for response
 */
function showTypingIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'message assistant typing-indicator-container';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    elements.messagesContainer.appendChild(indicator);
    scrollToBottom();
}

/**
 * Remove typing indicator
 */
function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) {
        indicator.remove();
    }
}

/**
 * Scroll chat to the bottom
 */
function scrollToBottom() {
    elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
}

/**
 * Show a temporary notification
 */
function showNotification(message, type = 'info') {
    // For now, just use alert. We can make this prettier later.
    // TODO: Create a nice toast notification
    console.log(`[${type}] ${message}`);
}

// ===== API Communication =====

/**
 * Send a message to the AI and get a response
 */
async function sendMessage() {
    const userMessage = elements.messageInput.value.trim();
    
    if (!userMessage || !state.settings.apiKey || state.isLoading) {
        return;
    }
    
    // Clear input and update state
    elements.messageInput.value = '';
    elements.messageInput.style.height = 'auto';
    state.isLoading = true;
    updateSendButtonState();
    
    // Add user message to chat
    appendMessage('user', userMessage);
    
    // Show typing indicator
    showTypingIndicator();
    
    try {
        // Make API call based on provider
        const response = await callAPI(userMessage);
        
        // Hide typing and show response
        hideTypingIndicator();
        appendMessage('assistant', response);
        
    } catch (error) {
        hideTypingIndicator();
        appendErrorMessage(error.message);
        console.error('API Error:', error);
    } finally {
        state.isLoading = false;
        updateSendButtonState();
    }
}

/**
 * Make the actual API call
 * This function handles the provider-specific logic
 */
async function callAPI(userMessage) {
    const { provider, model, apiKey, systemPrompt } = state.settings;
    
    if (provider === 'anthropic') {
        return await callAnthropicAPI(userMessage, model, apiKey, systemPrompt);
    }
    
    throw new Error(`Provider ${provider} not yet implemented`);
}

/**
 * Call the Anthropic (Claude) API
 */
async function callAnthropicAPI(userMessage, model, apiKey, systemPrompt) {
    // Build the messages array from conversation history
    // We need to convert our format to Anthropic's format
    const messages = state.conversation.map(msg => ({
        role: msg.role,
        content: msg.content
    }));
    
    // Note: The last message is the one we just added, so it's already included
    
    const requestBody = {
        model: model,
        max_tokens: 4096,
        system: systemPrompt,
        messages: messages
    };
    
    const response = await fetch(CONFIG.endpoints.anthropic, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
            'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error?.message || `API request failed with status ${response.status}`);
    }
    
    const data = await response.json();
    
    // Extract the text response
    // Claude returns content as an array of content blocks
    const textContent = data.content.find(block => block.type === 'text');
    
    if (!textContent) {
        throw new Error('No text response received from API');
    }
    
    return textContent.text;
}

// ===== Event Listeners =====

function setupEventListeners() {
    // Sidebar toggle
    elements.openSidebar.addEventListener('click', openSidebar);
    elements.closeSidebar.addEventListener('click', closeSidebar);
    
    // Settings
    elements.saveSettings.addEventListener('click', saveSettings);
    elements.clearChat.addEventListener('click', clearConversation);
    
    // API key visibility toggle
    elements.toggleApiKey.addEventListener('click', () => {
        const input = elements.apiKeyInput;
        input.type = input.type === 'password' ? 'text' : 'password';
    });
    
    // Message input
    elements.messageInput.addEventListener('input', () => {
        updateSendButtonState();
        autoResizeTextarea(elements.messageInput);
    });
    
    elements.messageInput.addEventListener('keydown', (e) => {
        // Send on Enter (without Shift)
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Send button
    elements.sendButton.addEventListener('click', sendMessage);
    
    // Model select change - update indicator
    elements.modelSelect.addEventListener('change', () => {
        elements.modelIndicator.textContent = getModelDisplayName(elements.modelSelect.value);
    });
}

// ===== Sidebar Functions =====

function createSidebarOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.id = 'sidebarOverlay';
    document.body.appendChild(overlay);
    
    overlay.addEventListener('click', closeSidebar);
}

function openSidebar() {
    elements.sidebar.classList.add('open');
    document.getElementById('sidebarOverlay').classList.add('visible');
}

function closeSidebar() {
    elements.sidebar.classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('visible');
}

// ===== Utility Functions =====

/**
 * Auto-resize textarea as user types
 */
function autoResizeTextarea(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
}

/**
 * Clear the conversation history
 */
function clearConversation() {
    if (confirm('Are you sure you want to clear the conversation? This cannot be undone.')) {
        state.conversation = [];
        saveConversation();
        renderConversation();
        closeSidebar();
    }
}

// ===== Start the App =====
// Wait for the DOM to be fully loaded, then initialize
document.addEventListener('DOMContentLoaded', init);
